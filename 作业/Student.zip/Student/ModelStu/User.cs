﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.ModelStu
{
    public class User
    {
        public string LoginPwd { get; set; }

        public string LoginId { get; set; }

        public string Guid { get; set; }

    }
}
