﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_1_3
{
    public enum Genders
    {
        //Male,Female
        男,女
    }
}
